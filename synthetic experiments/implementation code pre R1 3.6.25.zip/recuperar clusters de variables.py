import numpy as np
np.set_printoptions(suppress=True,precision=3)
import auxfuncs as aux
from instances import get_instances
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import os
import matplotlib.colors as mcolors
from itertools import groupby
import auxfuncs as aux
from instances import all_components_of_instances
import seaborn as sns

# Permanently changes the pandas settings
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)


######################################################################################################
metodo='nonzeros'
diccionarios_porR = {'1':[], '5':[], '10':[], '20':[], '30':[], '50':[], '100':[]}
criteria = ['B_1','B_2', 'B_3']
features = ['x_1', 'x_2', 'x_3', 'x_4','x_5', 'x_6', 'x_7', 'x_8', 'x_9']
grupos = list(range(len(features)))

######################################################################################################
executions = []
for element in os.listdir():
    if (".pkl" in element):
        print(element)
        with open(element, 'rb') as handle:
            archivo = pickle.load(handle)
            executions+=archivo
ex_dataframe = pd.DataFrame(executions)

######################################################################################################
#USANDO B_INV
for ex in executions:
    R = ex['R']
    model_status = 'opt' if ex['model_status']==2 else 'fact'
    try:
        parametros_inversos = ex['solutions_dataframe']['B_inv'][0]
        your_dict = {}
        for j in range(len(criteria)):
            B = parametros_inversos[j]
            assignment = B.sum(axis=1) != 0
            your_dict['B_'+str(j+1)] = [x for (x,b) in zip(features,assignment) if b]
        diccionarios_porR[str(R)].append((your_dict,model_status))
    except:
        None

######################################################################################################
#USANDO ETA ASIGNACION
"""
import matplotlib.pyplot as plt
from ast import literal_eval
import numpy as np
import seaborn as sns

# a partir de graficos.py saco:
lista_Rs = list(ex_dataframe[ex_dataframe['model_solcount']>0]['R'])
lista_sols = list(ex_dataframe[ex_dataframe['model_solcount']>0]['model_status'])

if metodo=='distideal':
    file = "CLUSTERS_l_1-feasibility-min_distideal-None-True.txt"
if metodo=='nonzeros':
    file = "CLUSTERS_l_1-feasibility-min_nonzeros-None-True.txt"

i = 0
with open(file, "r") as ins:
    for line in ins:
        your_dict = literal_eval(line)
        diccionarios_porR[str(lista_Rs[i])].append((your_dict,'opt' if lista_sols[i]==2 else 'fact'))
        i+=1
"""
######################################################################################################
"""
dibujo = {'B_1': {'x_1':0, 'x_2':0, 'x_3':0, 'x_4':0, 'x_5':0, 'x_6':0, 'x_7':0, 'x_8':0, 'x_9':0},
          'B_2': {'x_1':0, 'x_2':0, 'x_3':0, 'x_4':0, 'x_5':0, 'x_6':0, 'x_7':0, 'x_8':0, 'x_9':0},
          'B_3': {'x_1':0, 'x_2':0, 'x_3':0, 'x_4':0, 'x_5':0, 'x_6':0, 'x_7':0, 'x_8':0, 'x_9':0}}

for your_dict in diccionarios:
    for crit in criteria:
        for feat in features:

            if feat in your_dict[crit]:
                dibujo[crit][feat] +=1

valores = []
for v in dibujo.values():
    valores.append(list(v.values()))

fig, axs = plt.subplots()
axs.bar(grupos, valores[0], color="blue")
axs.bar(grupos, valores[1], bottom = valores[0], color="orange")
axs.bar(grupos, valores[2], bottom = np.add(valores[0], valores[1]), color="green")
#axs.set_title(gammas[gamma])
axs.set_ylabel("Count")

axs.set_xticks(grupos,features)
axs.set_xlabel("Features")

h = [plt.plot([],[], color=c)[0] for c in ["blue","orange","green"]]
fig.legend(h, labels=criteria, loc='lower center', title="Criteria:", ncol=3)
plt.show()

"""
###################################################################
from matplotlib.colors import ListedColormap, BoundaryNorm
cmap = ListedColormap(['w', 'b', 'orange', 'green'])
boundaries = list(range(len(criteria)+2))
norm = BoundaryNorm(boundaries, cmap.N)

fig, axs = plt.subplots(nrows=len(diccionarios_porR), ncols=1, sharex=True)
fig.suptitle(metodo)
row = 0
for (R, diccionarios) in diccionarios_porR.items():
    matriz = np.zeros((len(diccionarios), len(features)))
    type_sols = []
    i = 0
    for (your_dict,type_sol) in diccionarios:
        type_sols.append(type_sol)
        for crit in criteria:
            for feat in features:
                number_feat = int(feat[-1])-1
                number_crit = int(crit[-1])
                if feat in your_dict[crit]:
                    matriz[i][number_feat] = number_crit
        i+=1
    ax = axs[row]
    ax.set_title('R='+R)#+'. sols='+str(type_sols))
    ax.set_xticks(grupos,features)
    ax.set_yticks(list(range(len(diccionarios))),type_sols)
    cax = ax.matshow(matriz,cmap=cmap, norm=norm)
    row+=1

h = [plt.plot([],[], color=c)[0] for c in ["blue","orange", "green"]]
fig.legend(h, labels=criteria, loc='lower center', title="Criteria:", ncol=3)

plt.show()



#########################################

"""


#ejemplo


B_inv_0 = np.array(
 [[ 0.  ,   0.   ,  0.   ,  0.   ,  0.076 , 0.   ],
 [ 0.   ,  0.  ,   0. ,    0. ,    0.063 , 0.   ],
 [ 0.   ,  0.  ,   0.  ,   0.  ,  -0.995 , 0.   ],
 [ 0. ,    0. ,    0.   ,  0.  ,   0.  ,   0.   ]]
    )
B_inv_1 = np.array(
 [[ 0.,  0. , 0. , 0.  ,0. , 0.],
 [ 0. , 0. , 0. , 0. , 0.,  0.],
 [ 0. , 0. , 0.,  0.,  0.  ,0.],
 [ 0. , 0. , 0.  ,0. ,-1. , 0.]]
    )
w_inv= [0.5556532997397341, 0.4443463689782185]
B_inv_0 = w_inv[0]*B_inv_0
B_inv_1 = w_inv[1]*B_inv_1

x_r=  np.array([44.8 , 34.89, 0, 10]) 
z_r= np.array([ 2.5  , 0.83 , 0.25,  0. ,  10. ,   0.  ])
np.matmul( np.matmul(x_r, B_inv_0) , z_r)

"""