import numpy as np
np.set_printoptions(suppress=True,precision=3)
import auxfuncs as aux
from instances import get_instances
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import os
import matplotlib.colors as mcolors
from itertools import groupby
import auxfuncs as aux
from instances import all_components_of_instances
import seaborn as sns

# Permanently changes the pandas settings
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)


######################################################################################################

executions = []
for element in os.listdir():
    if (".pkl" in element):
        print(element)
        with open(element, 'rb') as handle:
            archivo = pickle.load(handle)
            executions+=archivo
ex_dataframe = pd.DataFrame(executions)


sols = []
for i in range(ex_dataframe.shape[0]):
    elem1 = ex_dataframe.loc[i,['seed', 'R', 'model_status','model_solcount']]
    elem2 = ex_dataframe.loc[i,'solutions_dataframe']
    if not elem2.empty:
        elem2 = elem2.loc[0,['obj_val','time_found','consistecy_achieved','mean_suboptimalitygap_in_frac','median_suboptimalitygap_in_frac','mean_suboptimalitygap_out_frac','median_suboptimalitygap_out_frac',]]
        elem = pd.concat([elem1,elem2])
        sols.append(elem)

sols = pd.DataFrame(sols)

#sols.round(2).to_csv("ALLexecutions.csv")


gammas={'l_1': r"$\gamma=\ell_1$", 'l_2': r"$\gamma=\ell_2$",'l_inf':r"$\gamma=\ell_\infty$"}
shapes = {'l_1':'o', 'l_2':'*', 'l_inf': '^'}

colors= ['b','r','g','purple','yellow'] # list(mcolors.TABLEAU_COLORS.values())#

var = 'obj_val'#'obj_val'#'time_found'#'median_suboptimalitygap_out_frac'


gamma="l_1"


fig,ax = plt.subplots()
values_gamma=[]

for seed in sols['seed'].unique():
    datos_gamma_seed = sols.loc[sols['seed']==seed,:].sort_values(by='R')
    for status in datos_gamma_seed['model_status'].unique():
        dat = datos_gamma_seed.loc[datos_gamma_seed['model_status']==status, ['R',var]].sort_values(by='R')
        x = dat.loc[:,'R']
        y = dat.loc[:,var]
        plt.scatter(x, y, s=100, marker=shapes[gamma],
                    facecolors=(colors[seed] if status==2 else 'none'), edgecolors=colors[seed])
        values_gamma += zip(x,y)
#median value
values_gamma.sort(key=lambda x: x[0])
groups = groupby(values_gamma, lambda x: x[0])
values_gamma = [(k, [v for _, v in group]) for k, group in groups]
plt.plot(list(zip(*values_gamma))[0], [np.median(l) for l in list(zip(*values_gamma))[1]], marker=shapes[gamma], color='k', label=gamma)

plt.xlabel('sample size R')
plt.ylabel(var)
plt.show()





#CONTEO PARA NUEVO CJTO DATOS
fig, axs = plt.subplots()
dibujo = {'opt': {1:0, 5:0, 10:0, 20:0, 30:0, 50:0, 100:0},
          'subopt': {1:0, 5:0, 10:0, 20:0, 30:0, 50:0, 100:0},
          'none': {1:0, 5:0, 10:0, 20:0, 30:0, 50:0, 100:0}}

grupos = sols.groupby(['R','model_status'])['seed'].count().reset_index()
for R in sols['R'].unique():
    grupo_R = grupos[grupos['R']==R]
    tot = 0
    for stat in grupo_R['model_status'].unique():
        val = list(grupo_R[(grupo_R['model_status']==stat)]['seed']).pop()
        tot +=val 
        if stat == 2:
            dibujo['opt'][R] = val
        else:
            dibujo['subopt'][R] += val
    if tot <5:
        dibujo['none'][R] = 5-tot

dibujo
grupos = np.array(sols['R'].unique())
valores = []
for v in dibujo.values():
    valores.append(list(v.values()))
axs.bar(grupos, valores[0], color="g")
axs.bar(grupos, valores[1], bottom = valores[0], color="orange")
axs.bar(grupos, valores[2], bottom = np.add(valores[0], valores[1]), color="r")
axs.set_title(gammas[gamma])
axs.set_ylabel("Count")



axs.set_xticks(grupos)
axs.set_xlabel("Sample size")

h = [plt.plot([],[], color=c)[0] for c in ["g","orange","r"]]
fig.legend(h, labels=["Optimality", "Subopt. feasibility", "Not solved in time limit"], loc='lower center', title="Solved instances to:", ncol=3)
plt.show()






"""
fig,axs = plt.subplots()
fig.suptitle(gammas[gamma])
val_gamma = sols.loc[:,['obj_val','R', 'median_suboptimalitygap_out_frac']].groupby(['obj_val','R']).median()
val_gamma = val_gamma.reset_index()
val_gamma = val_gamma.pivot(index="obj_val", columns="R", values="median_suboptimalitygap_out_frac")
#val_gamma.sort_index(level=0, ascending=False, inplace=True)
sns.heatmap(val_gamma,cmap="crest")
axs.set(xlabel="Sample size", ylabel=" sparsity: total number of nonzero elements")
    
plt.show()
"""

#SPARSITY VS GAP
fig,ax = plt.subplots()
plt.scatter(sols['obj_val'], sols['median_suboptimalitygap_out_frac'])
dat = sols.loc[:,['obj_val','median_suboptimalitygap_out_frac']].groupby(['obj_val']).median().reset_index()
x = dat.loc[:,'obj_val']
y = dat.loc[:,'median_suboptimalitygap_out_frac']
plt.xlabel('sparsity: total number of nonzero elements')
plt.ylabel('median_suboptimalitygap_out_frac')
plt.plot(x,y)
plt.show()


#diferenciando por R pero no mola porque no hay para todos los valores de sparsity
"""
fig,ax = plt.subplots()
for R in sols['R'].unique():
    sols_R = sols[sols['R']==R]
    plt.scatter(sols_R['obj_val'],sols_R['median_suboptimalitygap_out_frac'])
    dat = sols_R.loc[:,['obj_val','median_suboptimalitygap_out_frac']].groupby(['obj_val']).median().reset_index()
    x = dat.loc[:,'obj_val']
    y = dat.loc[:,'median_suboptimalitygap_out_frac']
    plt.xlabel('sparsity: total number of nonzero elements')
    plt.ylabel('median_suboptimalitygap_out_frac')
    plt.plot(x,y, label=str(R))
plt.legend()
plt.show()
"""





























##################################################################################################################



"""
with open('ALLexecutions.pkl', 'wb') as handle:
    pickle.dump(ex_dataframe, handle, protocol=pickle.HIGHEST_PROTOCOL)


with open("ALLexecutions.pkl", 'rb') as handle:
    ex_dataframe = pickle.load(handle)
"""

########################################################################
#grafico de cuantas instancias se resuelven a optimalidad, factibilidad, nada cuando sparsity=None para cada gamma y R

ex_dataframe_sparsitynone = ex_dataframe.loc[[e is None for e in ex_dataframe['sparsity_imposed']],:]

fig, axs = plt.subplots(3,1, sharex=True)
i=0
gammas={'l_1': r"$\gamma=\ell_1$", 'l_2': r"$\gamma=\ell_2$",'l_inf':r"$\gamma=\ell_\infty$"}
for gamma in ["l_1","l_2","l_inf"]:
    dat_gamma = ex_dataframe_sparsitynone.loc[ex_dataframe['gamma']==gamma,:]
    
    dibujo = {(2,'geq1'): {5:0, 10:0, 15:0, 20:0, 25:0, 30:0},
              (9,'geq0'): {5:0, 10:0, 15:0, 20:0, 25:0, 30:0},
              (9,'=0'): {5:0, 10:0, 15:0, 20:0, 25:0, 30:0}}
    for R in dat_gamma['R'].unique():
        dat_gamma_R = dat_gamma.loc[dat_gamma['R']==R,:]
        groups = dat_gamma_R.groupby(['model_status','model_solcount'])
        for model_status in dat_gamma['model_status'].unique():
            for model_solcount in dat_gamma['model_solcount'].unique():
                try:
                    count = groups.get_group((model_status,model_solcount)).shape[0]
                except:
                    count = 0

                if model_solcount >0:
                    if model_status == 2:
                        dibujo[(2,'geq1')][R] += count
                    else:
                        dibujo[(9,'geq0')][R] += count
                else:
                        dibujo[(9,'=0')][R] += count
    dibujo
    grupos = np.array(dat_gamma['R'].unique())
    valores = []
    for v in dibujo.values():
        valores.append(list(v.values()))
    axs[i].bar(grupos, valores[0], color="g")
    axs[i].bar(grupos, valores[1], bottom = valores[0], color="orange")
    axs[i].bar(grupos, valores[2], bottom = np.add(valores[0], valores[1]), color="r")
    axs[i].set_title(gammas[gamma])
    axs[i].set_ylabel("Count")
    i+=1

axs[2].set_xticks(grupos)
axs[2].set_xlabel("Sample size")

h = [plt.plot([],[], color=c)[0] for c in ["g","orange","r"]]
fig.legend(h, labels=["Optimality", "Subopt. feasibility", "Not solved in time limit"], loc='lower center', title="Solved instances to:", ncol=3)
plt.show()

########################################################################





#shape by gamma
shapes = {'l_1':'o', 'l_2':'*', 'l_inf': '^'}
#color by seed https://matplotlib.org/stable/gallery/color/named_colors.html
colors = {'l_1':'m', 'l_2':'c', 'l_inf': 'y'}#list(dict(mcolors.BASE_COLORS).keys())[:6]+['k']#list(mcolors.TABLEAU_COLORS.values())+['k']#['b','g','r','c','m','y','k','w']
#filled by model_status optimal or feasible https://stackoverflow.com/questions/4143502/how-to-do-a-scatter-plot-with-empty-circles-in-python



ex_dataframe_sparsitynone_solved = ex_dataframe_sparsitynone.loc[ex_dataframe_sparsitynone['model_solcount']>0,:]
#ex_dataframe_sparsitynone_solved = ex_dataframe.loc[ex_dataframe['model_solcount']>0,:]


# val obj INV vs. R
fig,ax = plt.subplots()
for gamma in ex_dataframe_sparsitynone_solved['gamma'].unique():
    values_gamma = []
    datos_gamma = ex_dataframe_sparsitynone_solved.loc[ex_dataframe_sparsitynone_solved['gamma']==gamma]
    for seed in datos_gamma['seed'].unique():
        datos_gamma_seed = datos_gamma.loc[datos_gamma['seed']==seed,:].sort_values(by='R')
        for status in datos_gamma_seed['model_status'].unique():
            dat = datos_gamma_seed.loc[datos_gamma_seed['model_status']==status, ['R','obj_val_inv']].sort_values(by='R')
            x = dat.loc[:,'R']
            y = dat.loc[:,'obj_val_inv']
            plt.scatter(x, y, s=100, marker=shapes[gamma],
                        facecolors=(colors[gamma] if status==2 else 'none'), edgecolors=colors[gamma])
            values_gamma += zip(x,y)
    #median value
    values_gamma.sort(key=lambda x: x[0])
    groups = groupby(values_gamma, lambda x: x[0])
    values_gamma = [(k, [v for _, v in group]) for k, group in groups]
    plt.plot(list(zip(*values_gamma))[0], [np.median(l) for l in list(zip(*values_gamma))[1]], marker=shapes[gamma], color=colors[gamma], label=gamma)

plt.legend()

plt.suptitle("Val obj inv vs. sample size")
plt.xlabel('Sample size')
plt.xticks(ex_dataframe_sparsitynone_solved['R'].unique())
plt.ylabel('Val obj inv (in sample)')
plt.show()













# tiempo computo vs. R
for gamma in ex_dataframe_sparsitynone_solved['gamma'].unique():
    values_gamma = []
    datos_gamma = ex_dataframe_sparsitynone_solved.loc[ex_dataframe_sparsitynone_solved['gamma']==gamma]
    for seed in datos_gamma['seed'].unique():
        datos_gamma_seed = datos_gamma.loc[datos_gamma['seed']==seed,:].sort_values(by='R')
        for status in datos_gamma_seed['model_status'].unique():
            dat = datos_gamma_seed.loc[datos_gamma_seed['model_status']==status, ['R','tiempo_computo']].sort_values(by='R')
            x = dat.loc[:,'R']
            y = dat.loc[:,'tiempo_computo']
            plt.scatter(x, y, s=100, marker=shapes[gamma],
                        facecolors=(colors[gamma] if status==2 else 'none'), edgecolors=colors[gamma])
            values_gamma += zip(x,y)
    #median value
    values_gamma.sort(key=lambda x: x[0])
    groups = groupby(values_gamma, lambda x: x[0])
    values_gamma = [(k, [v for _, v in group]) for k, group in groups]
    plt.plot(list(zip(*values_gamma))[0], [np.median(l) for l in list(zip(*values_gamma))[1]], marker=shapes[gamma], color=colors[gamma], label=gamma)

plt.legend()

plt.suptitle("Computation time vs. sample size when no sparsity is imposed")
plt.xlabel('Sample size')
plt.xticks(ex_dataframe_sparsitynone_solved['R'].unique())
plt.ylabel('Computation time (s.)')
plt.show()

#########################################################
#optimality gap (a futuro) vs. R 

fig,ax = plt.subplots()
measure= 'median_suboptimalitygap_out_frac'
for gamma in ex_dataframe_sparsitynone_solved['gamma'].unique():
    values_gamma = []
    datos_gamma = ex_dataframe_sparsitynone_solved.loc[ex_dataframe_sparsitynone_solved['gamma']==gamma]
    for seed in datos_gamma['seed'].unique():
        datos_gamma_seed = datos_gamma.loc[datos_gamma['seed']==seed,:].sort_values(by='R')
        for status in datos_gamma_seed['model_status'].unique():
            dat = datos_gamma_seed.loc[datos_gamma_seed['model_status']==status, ['R',measure,"model_solcount"]].sort_values(by='R')
            x = dat.loc[:,'R']
            y = dat.loc[:,measure]
            plt.scatter(x, y, s=100, marker=shapes[gamma],
                        color=colors_seeds[seed])
                        #facecolors=(colors[gamma] if status==2 else 'none'), edgecolors=colors[gamma])
            values_gamma += zip(x,y)
    #median value
    values_gamma.sort(key=lambda x: x[0])
    groups = groupby(values_gamma, lambda x: x[0])
    values_gamma = [(k, [v for _, v in group]) for k, group in groups]
    plt.plot(list(zip(*values_gamma))[0], [np.median(l) for l in list(zip(*values_gamma))[1]],
             marker=shapes[gamma], color=colors[gamma],label=gamma)
plt.legend()
plt.suptitle("R vs. "+measure+" (out of sample)")
plt.xlabel('Sample size')
plt.xticks(ex_dataframe_sparsitynone_solved['R'].unique())
plt.ylabel(measure+" (out of sample)")
plt.show()



#############################################################################
fig,ax = plt.subplots()
measure= 'mean_suboptimalitygap_in_frac'
for gamma in ["l_2", "l_inf"]:# ex_dataframe_sparsitynone_solved['gamma'].unique():
    values_gamma = []
    datos_gamma = ex_dataframe_sparsitynone_solved.loc[ex_dataframe_sparsitynone_solved['gamma']==gamma]
    non_solved = {}
    for r in datos_gamma['R'].unique():
        non_solved[r] = []
    for seed in datos_gamma['seed'].unique():
        datos_gamma_seed = datos_gamma.loc[datos_gamma['seed']==seed,:].sort_values(by='R')
        for status in datos_gamma_seed['model_status'].unique():
            dat = datos_gamma_seed.loc[datos_gamma_seed['model_status']==status, ['R',measure,"model_solcount"]].sort_values(by='R')
            x = dat.loc[:,'R']
            y = dat.loc[:,measure]
            plt.scatter(x, y, s=100, marker=shapes[gamma],
                        facecolors=(colors[gamma] if status==2 else 'none'), edgecolors=colors[gamma])
            values_gamma += zip(x,y)
    #median value
    values_gamma.sort(key=lambda x: x[0])
    groups = groupby(values_gamma, lambda x: x[0])
    values_gamma = [(k, [v for _, v in group]) for k, group in groups]
    plt.plot(list(zip(*values_gamma))[0], [np.median(l) for l in list(zip(*values_gamma))[1]], marker=shapes[gamma], color=colors[gamma],label=gamma)

plt.legend()
plt.suptitle("R vs. "+measure+" (IN sample) for all sparsity runs")
plt.xlabel('Sample size')
plt.xticks(ex_dataframe_solved['R'].unique())
plt.ylabel(measure+" (IN sample)")
plt.show()

############################################################################



################################################
#sparsitys

type_sparsity='effective'
ex_dataframe[type_sparsity+'_N_T'] = ex_dataframe['sparsity_'+type_sparsity].apply(lambda x: x[0] if x is not None else 3)
ex_dataframe['y_'+type_sparsity+'_N_A_N_d'] = ex_dataframe['sparsity_'+type_sparsity].apply(lambda x: 0 if (x is None or x[2]==[6,6,6]) else (1 if x[2]==[5,5,5] else 2))
ex_dataframe_solved = ex_dataframe.loc[ex_dataframe['model_solcount']>0, ['gamma','R',type_sparsity+'_N_T', 'y_'+type_sparsity+'_N_A_N_d','mean_suboptimalitygap_out_frac']]
valores = ex_dataframe_solved.groupby(['gamma','R',type_sparsity+'_N_T', 'y_'+type_sparsity+'_N_A_N_d']).mean()
valores = valores.reset_index()



for gamma in ["l_1","l_2","l_inf"]:
    fig,axs = plt.subplots(2,1)
    fig.suptitle(gammas[gamma])
    val_gamma = valores.loc[valores['gamma']==gamma,[type_sparsity+'_N_T','y_'+type_sparsity+'_N_A_N_d','R', 'mean_suboptimalitygap_out_frac']]
    val_gamma_NT = val_gamma.loc[val_gamma['y_'+type_sparsity+'_N_A_N_d']==0, [type_sparsity+'_N_T','R', 'mean_suboptimalitygap_out_frac']]
    val_gamma_NT = val_gamma_NT.pivot(index=type_sparsity+"_N_T", columns="R", values="mean_suboptimalitygap_out_frac")
    sns.heatmap(val_gamma_NT,cmap="crest",ax=axs[0])
    axs[0].set(xlabel="Sample size", ylabel=r"$N_T$ of "+type_sparsity+" sparsity total number of nonzero matrices")
    

    val_gamma_N_A_N_d = val_gamma.loc[val_gamma[type_sparsity+'_N_T']==3, ['y_'+type_sparsity+'_N_A_N_d','R', 'mean_suboptimalitygap_out_frac']]
    val_gamma_N_A_N_d = val_gamma_N_A_N_d.pivot(index="y_"+type_sparsity+"_N_A_N_d", columns="R", values="mean_suboptimalitygap_out_frac")
    val_gamma_N_A_N_d.sort_index(level=0, ascending=False, inplace=True)
    sns.heatmap(val_gamma_N_A_N_d,cmap="crest",ax=axs[1])
    axs[1].set(xlabel="Sample size", ylabel=r"$y$ of "+type_sparsity+r" sparsity $(N_A^j - y)$ and $(N_V^j - y)$ $\forall j$")
    
    plt.show()



################################################
#sparsitys effective

type_sparsity='effective'
measure = 'median_suboptimalitygap_out_frac'
ex_dataframe_solved = ex_dataframe.loc[ex_dataframe['model_solcount']>0, :].copy()
ex_dataframe_solved[type_sparsity+'_N_T'] = ex_dataframe_solved['sparsity_'+type_sparsity].apply(lambda x: x[0])
ex_dataframe_solved[type_sparsity+'_N_A_sum'] = ex_dataframe_solved['sparsity_'+type_sparsity].apply(lambda x: np.sum(x[1]))
ex_dataframe_solved[type_sparsity+'_N_V_sum'] = ex_dataframe_solved['sparsity_'+type_sparsity].apply(lambda x: np.sum(x[2]))
ex_dataframe_solved = ex_dataframe_solved.loc[:,['gamma','R',type_sparsity+'_N_T',type_sparsity+'_N_A_sum',type_sparsity+'_N_V_sum',measure]]

valores = ex_dataframe_solved.groupby(['gamma','R',type_sparsity+'_N_T', type_sparsity+'_N_A_sum',type_sparsity+'_N_V_sum']).mean()
valores = valores.reset_index()



import seaborn as sns

#solo por N_T
for gamma in ["l_1","l_2","l_inf"]:
    """
    fig = plt.figure()
    fig.suptitle(gammas[gamma])
    val_gamma = valores.loc[valores['gamma']==gamma,[type_sparsity+'_N_T','R', measure]]
    val_gamma_NT = val_gamma.groupby(['R',type_sparsity+'_N_T']).mean()
    val_gamma_NT = val_gamma_NT.reset_index()
    val_gamma_NT = val_gamma_NT.pivot(index=type_sparsity+"_N_T", columns="R", values=measure)
    sns.heatmap(val_gamma_NT,cmap="crest")
    #axs[0].set(xlabel="Sample size", ylabel=r"$N_T$ of "+type_sparsity+" sparsity total number of nonzero matrices")
    plt.show()
    """

    fig,axs = plt.subplots(2,3)
    fig.suptitle(gammas[gamma])
    val_gamma = valores.loc[valores['gamma']==gamma,:]
    val_gamma = valores.loc[valores['gamma']==gamma,:]
    for N_T in [1,2,3]:
        axs[0,N_T-1].set_title(r"$N_T=$"+str(N_T))
        val_gamma_NT = val_gamma.loc[val_gamma[type_sparsity+'_N_T']==N_T,['R',type_sparsity+'_N_A_sum', measure]]
        val_gamma_NT_NA = val_gamma_NT.groupby(['R',type_sparsity+'_N_A_sum']).mean()
        val_gamma_NT_NA = val_gamma_NT_NA.reset_index()
        val_gamma_NT_NA = val_gamma_NT_NA.pivot(index=type_sparsity+"_N_A_sum", columns="R", values=measure)
        val_gamma_NT_NA.sort_index(level=0, ascending=False, inplace=True)
        sns.heatmap(val_gamma_NT_NA,cmap="crest", ax=axs[0,N_T-1])

        axs[1,N_T-1].set_title(r"$N_T=$"+str(N_T))
        val_gamma_NT = val_gamma.loc[val_gamma[type_sparsity+'_N_T']==N_T,['R',type_sparsity+'_N_V_sum', measure]]
        val_gamma_NT_NV = val_gamma_NT.groupby(['R',type_sparsity+'_N_V_sum']).mean()
        val_gamma_NT_NV = val_gamma_NT_NV.reset_index()
        val_gamma_NT_NV = val_gamma_NT_NV.pivot(index=type_sparsity+"_N_V_sum", columns="R", values=measure)
        val_gamma_NT_NV.sort_index(level=0, ascending=False, inplace=True)
        sns.heatmap(val_gamma_NT_NV,cmap="crest", ax=axs[1,N_T-1])
        
        
        #axs[0].set(xlabel="Sample size", ylabel=r"$N_T$ of "+type_sparsity+" sparsity total number of nonzero matrices")
    plt.show()




"""Ç
ex_dataframe_sparsityimposed = ex_dataframe.loc[[e is not None for e in ex_dataframe['sparsity_imposed']],:]
ex_dataframe_sparsityimposed_optimality = ex_dataframe_sparsityimposed.loc[ex_dataframe_sparsityimposed['solve_to']=='optimality',:]

ex_dataframe_sparsityimposed_optimality['sparsity_effective_string'] = ex_dataframe_sparsityimposed_optimality['sparsity_effective'].apply(lambda x: str(x)[4:-1] if x is not None else 'FAIL')
ex_dataframe_sparsityimposed_optimality['sparsity_effective_N_T'] = ex_dataframe_sparsityimposed_optimality['sparsity_effective'].apply(lambda x: str(x)[1] if x is not None else 'FAIL')


"""
colors = list(dict(mcolors.BASE_COLORS).values())[:6]+\
    [mcolors.TABLEAU_COLORS['tab:'+n] for n in ['orange','purple','brown']]+\
    [mcolors.CSS4_COLORS[n] for n in ['lightcoral','palegreen','skyblue','fuchsia','lime','gold']]
shapes = {0: 'o', 1: '^', 2: 's', 3: '*', 4: 'd'} #https://matplotlib.org/stable/api/markers_api.html


measure = 'median_suboptimalitygap_out'
for gamma in ex_dataframe_sparsityimposed_optimality['gamma'].unique():
    filter_by_gamma = ex_dataframe_sparsityimposed_optimality.loc[ex_dataframe_sparsityimposed_optimality['gamma']==gamma,:]
    
    sparsitys = filter_by_gamma['sparsity_effective_string'].unique()
    sparsitys.sort()

    matrices_considered = filter_by_gamma['sparsity_effective_N_T'].unique()
    matrices_considered = matrices_considered[matrices_considered!='FAIL']
    j = len(matrices_considered) if len(sparsitys)>10 else 1
    fig, axs = plt.subplots(nrows=1, ncols=j)
    fig.suptitle("R vs. "+measure+" (100 instances out of sample) when different degrees of sparsity imposed \ngamma="+gamma)
    h = [plt.plot([],[], color="gray", marker=list(shapes.values())[i])[0] for i in range(5)]
    fig.legend(h, labels=list(shapes.keys()), loc='lower center', title="Seed", ncol=5)
    for i in range(j):
        ax = axs[i] if j>1 else axs
        nmatrices = matrices_considered[i]
        filter_by_gamma_nmatrices = filter_by_gamma.loc[filter_by_gamma['sparsity_effective_N_T']==nmatrices,:]
        sparsitys = filter_by_gamma_nmatrices['sparsity_effective_string'].unique()
        sparsitys.sort()
        c=0
        values_gamma = []
        for sparsity in sparsitys:
            for seed in filter_by_gamma_nmatrices['seed'].unique():
                datos = filter_by_gamma_nmatrices.loc[filter_by_gamma['sparsity_effective_string']==sparsity, :]
                datos = datos.loc[datos['seed']==seed, :]
                x = datos.loc[:,'R']
                y = datos.loc[:,measure]
                values_gamma+=list(zip(x,y))
                ax.scatter(x, y, marker=shapes[seed], color=colors[c], label = sparsity)
            c+=1
        values_gamma.sort(key=lambda x: x[0])
        groups = groupby(values_gamma, lambda x: x[0])
        median_gamma = [(k, np.median([v for _, v in group])) for k, group in groups]
        ax.plot(list(zip(*median_gamma))[0], list(zip(*median_gamma))[1], color='k')

        h1 = [plt.plot([],[], marker=",", color=colors[i])[0] for i in range(c)]
        ax.legend(loc="upper right", handles=h1, labels=list(sparsitys), title="Sparsity effective")
        
        ax.set_xlabel('Sample size')
        ax.set_xticks(filter_by_gamma['R'].unique())
        ax.set_ylabel('Suboptimality gap')
        ax.set_title("no. nonzero matrices = "+nmatrices)
    
    plt.show()


"""


#############
#todo en 1 grafico y shape por numero de matrices no nulas
colors = list(dict(mcolors.BASE_COLORS).values())[:6]+\
    [mcolors.TABLEAU_COLORS['tab:'+n] for n in ['orange','purple','brown',"gray"]]+\
    [mcolors.CSS4_COLORS[n] for n in ['lightcoral','palegreen','skyblue','fuchsia','lime','gold',"yellow", ]]
shapes = {'1': 'o', '2': '^', '3': 's'} #https://matplotlib.org/stable/api/markers_api.html

measure = 'median_suboptimalitygap_out'
for gamma in ex_dataframe_sparsityimposed_optimality['gamma'].unique():
    fig, axs = plt.subplots()
    fig.suptitle("R vs. "+measure+" (100 instances out of sample) when different degrees of sparsity imposed \ngamma="+gamma)
    filter_by_gamma = ex_dataframe_sparsityimposed_optimality.loc[ex_dataframe_sparsityimposed_optimality['gamma']==gamma,:]
    
    sparsitys = []
    values_gamma = {}
    for N_T in ['1','2','3']:
        values_gamma[N_T] = []
        sparsitys+=list(filter_by_gamma.loc[filter_by_gamma['sparsity_effective_N_T']==N_T,'sparsity_effective_string'].unique())
    #sparsitys = filter_by_gamma['sparsity_effective_string'].unique()
    #sparsitys.sort()
    c=0

    for sparsity in sparsitys:
        print(sparsity)
        datos = filter_by_gamma.loc[filter_by_gamma['sparsity_effective_string']==sparsity, :]
        matrices_considered = datos['sparsity_effective_N_T'].unique()[0]
        x = datos.loc[:,'R']
        y = datos.loc[:,measure]
        values_gamma[matrices_considered]+= list(zip(x,y))
        #values_gamma+=list(zip(x,y))
        plt.scatter(x, y, s=100, marker=shapes[matrices_considered], color=colors[c], label = sparsity)
        c+=1
    
    for N_T in ['1','2','3']:
        values = values_gamma[N_T]
        values.sort(key=lambda x: x[0])
        groups = groupby(values, lambda x: x[0])
        median_gamma = [(k, np.mean([v for _, v in group])) for k, group in groups]
        plt.plot(list(zip(*median_gamma))[0], list(zip(*median_gamma))[1], color='k', marker=shapes[N_T], label=N_T+"_mean")

    plt.legend(bbox_to_anchor=(1.1, 0.5), loc="center right")
    plt.xlabel('Sample size')
    plt.xticks(filter_by_gamma['R'].unique())
    plt.ylabel('Suboptimality gap')
    
    plt.show()
    












################################
colors = list(dict(mcolors.BASE_COLORS).values())[:6]+\
    [mcolors.TABLEAU_COLORS['tab:'+n] for n in ['orange','purple','brown']]+\
    [mcolors.CSS4_COLORS[n] for n in ['lightcoral','palegreen','skyblue','fuchsia','lime','gold']]
shapes = {0: 'o', 1: '^', 2: 's', 3: '*', 4: 'd'} #https://matplotlib.org/stable/api/markers_api.html

ex_dataframe_sparsityimposed = ex_dataframe.loc[[e is not None for e in ex_dataframe['sparsity_imposed']],:]
ex_dataframe_sparsityimposed_optimality = ex_dataframe_sparsityimposed.loc[ex_dataframe_sparsityimposed['solve_to']=='optimality',:]

ex_dataframe_sparsityimposed_optimality['sparsity_effective_string'] = ex_dataframe_sparsityimposed_optimality['sparsity_effective'].apply(lambda x: str(x)[4:-1] if x is not None else 'FAIL')
ex_dataframe_sparsityimposed_optimality['sparsity_effective_N_T'] = ex_dataframe_sparsityimposed_optimality['sparsity_effective'].apply(lambda x: str(x)[1] if x is not None else 'FAIL')

#para sacar graficas solo hasta 30
#ex_dataframe_sparsityimposed_optimality = ex_dataframe_sparsityimposed_optimality.loc[ex_dataframe_sparsityimposed_optimality['R']<50]
measure = 'median_suboptimalitygap_out_frac'
for gamma in ex_dataframe_sparsityimposed_optimality['gamma'].unique():
    filter_by_gamma = ex_dataframe_sparsityimposed_optimality.loc[ex_dataframe_sparsityimposed_optimality['gamma']==gamma,:]
    
    imposeds = filter_by_gamma['sparsity_imposed'].apply(lambda x: str(x)).unique()
    fig, axs = plt.subplots(figsize=(25,50), nrows=len(imposeds), ncols=1)
    fig.suptitle("R vs. "+measure+" (100 instances out of sample) when different degrees of sparsity imposed \ngamma="+gamma)
    h = [plt.plot([],[], color="gray", marker=list(shapes.values())[i])[0] for i in range(5)]
    fig.legend(h, labels=list(shapes.keys()), loc='lower center', title="Seed", ncol=5)
        
    for i in range(len(imposeds)):
        imposed = imposeds[i]
        filter_by_gamma_imposed = filter_by_gamma.loc[[str(s)==imposed for s in filter_by_gamma['sparsity_imposed']],:]
        sparsitys = filter_by_gamma_imposed['sparsity_effective_string'].unique()
        sparsitys.sort()
        
        ax = axs[i]
        c=0
        values_gamma = []
        for sparsity in sparsitys:
            if sparsity!='FAIL':
                for seed in filter_by_gamma_imposed['seed'].unique():
                    datos = filter_by_gamma_imposed.loc[filter_by_gamma_imposed['sparsity_effective_string']==sparsity, :]
                    datos = datos.loc[datos['seed']==seed, :]
                    x = datos.loc[:,'R']
                    y = datos.loc[:,measure]
                    values_gamma+=list(zip(x,y))
                    ax.scatter(x, y, marker=shapes[seed], color=colors[c], label = sparsity)
                c+=1
        values_gamma.sort(key=lambda x: x[0])
        groups = groupby(values_gamma, lambda x: x[0])
        median_gamma = [(k, np.median([v for _, v in group])) for k, group in groups]
        ax.plot(list(zip(*median_gamma))[0], list(zip(*median_gamma))[1], color='k')

        h1 = [plt.plot([],[], marker=",", color=colors[i])[0] for i in range(c)]
        ax.legend(loc="upper right", handles=h1, labels=list(sparsitys), title="Sparsity effective")

        ax.set_xlabel('Sample size')
        ax.set_xticks(filter_by_gamma['R'].unique())
        ax.set_ylabel('Suboptimality gap')
        ax.set_title("Original sparsity imposed = "+imposed)
    
    plt.savefig("sparsitysl2.svg")
    plt.show()






############################


for N_T in [1,2,3]:
    filter_by_nmatrices = ex_dataframe_sparsityimposed_optimality.loc[ex_dataframe_sparsityimposed_optimality['sparsity_effective_N_T']==str(N_T),:]
    if filter_by_nmatrices.shape[0]>0:
        fig, ax = plt.subplots()
        sparsitys = filter_by_nmatrices['sparsity_effective_string'].unique()
        sparsitys.sort()
        c=0
        dict_values = {'l_1': [], 'l_2': [], 'l_inf': []}
        for sparsity in sparsitys:
            datos = filter_by_nmatrices.loc[filter_by_nmatrices['sparsity_effective_string']==sparsity, :]
            for gamma in datos['gamma'].unique():
                x = datos.loc[datos['gamma']==gamma,'R']
                y = datos.loc[datos['gamma']==gamma,'mean_suboptimalitygap_out']
                dict_values[gamma]+=list(zip(x,y))
                plt.scatter(x, y, marker=shapes[gamma], color=colors[c], label = sparsity)
            c+=1
        for gamma in ['l_1','l_2','l_inf']:
            values_gamma = dict_values[gamma]
            values_gamma.sort(key=lambda x: x[0])
            groups = groupby(values_gamma, lambda x: x[0])
            median_gamma = [(k, [v for _, v in group]) for k, group in groups]
            #median_gamma = [(k, np.median(l) if len(l)==5 else np.nan) for (k,l) in median_gamma]
            #median_gamma = [(k, np.median(l)) for (k,l) in median_gamma]
            if len(median_gamma)>0:
                plt.plot(list(zip(*median_gamma))[0], [np.median(l) for l in list(zip(*median_gamma))[1]], marker=shapes[gamma], color='k')

        h1 = [plt.plot([],[], marker=",", color=colors[i])[0] for i in range(c)]
        leg1 = plt.legend(loc="upper right", handles=h1, labels=list(sparsitys), title="Sparsity effective")
        ax.add_artist(leg1)
        h2 = [plt.plot([],[], color="gray", marker=list(shapes.values())[i])[0] for i in range(3)]
        leg2 = plt.legend(loc="lower right", handles=h2, labels=list(shapes.keys()), title="Gamma")
        ax.add_artist(leg2)
        plt.suptitle("R vs. mean suboptimalitygap (out of sample)")
        plt.title("Sparsity imposed resulted in "+str(N_T)+" monzero matrices")
        plt.xlabel('Sample size')
        plt.xticks(ex_dataframe_sparsitynone_optimality['R'].unique())
        plt.ylabel('mean suboptimalitygap (out of sample)')
        plt.show()
"""